package be.technifutur.java.DemoMongoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
